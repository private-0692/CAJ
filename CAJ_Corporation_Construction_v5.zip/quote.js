function v(id){return document.getElementById(id).value.trim()}
let q=null;
function verifyQuote(){
 const ids=['first','last','address','city','state','zip','phone','clientEmail','details'];
 if(ids.some(id=>!v(id))){alert('Completa todos los campos.');return}
 q={Nombre:v('first')+' '+v('last'),Dirección:v('address')+', '+v('city')+', '+v('state')+' '+v('zip'),Teléfono:v('phone'),Email:v('clientEmail'),Proyecto:v('type'),Detalles:v('details')};
 summary.style.display='block';
 summary.innerHTML='<b>Verifica tu información:</b><br>'+Object.entries(q).map(x=>'<p><b>'+x[0]+':</b> '+x[1]+'</p>').join('');
 send.style.display='inline-block';
 summary.scrollIntoView({behavior:'smooth'});
}
quoteForm.addEventListener('submit',e=>{
 e.preventDefault();
 if(!q){verifyQuote();return}
 const requests=JSON.parse(localStorage.getItem('cajRequests')||'[]');
 const request={...q,id:'CAJ-'+Date.now(),status:'Recibida',created:new Date().toISOString()};
 requests.push(request);
 localStorage.setItem('cajRequests',JSON.stringify(requests));
 document.querySelector('.form').innerHTML=`
   <div class="status-card">
     <div class="spinner"></div>
     <h2>Solicitud recibida ✅</h2>
     <p>Tranquilo, tu solicitud ya quedó registrada.</p>
     <p><b>Número de solicitud:</b> ${request.id}</p>
     <div class="progress"><span></span></div>
     <p id="waitText">Estamos revisando la información…</p>
     <a class="btn" href="index.html">Volver al inicio</a>
   </div>`;
 setTimeout(()=>{const t=document.getElementById('waitText');if(t)t.textContent='Gracias por tu paciencia. La corporación revisará tu solicitud y se comunicará contigo.'},2200);
});
